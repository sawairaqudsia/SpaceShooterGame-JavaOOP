package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

/**
 * INHERITANCE: BasicEnemy extends Enemy (which extends GameObject)
 * POLYMORPHISM: Overrides move() and render() with its own behavior
 */
public class BasicEnemy extends Enemy {

    private int moveTimer = 0;

    public BasicEnemy(int x, int y, List<Bullet> bulletList) {
        super(x, y, 40, 36, 30, 2, 100, 90, bulletList);
    }

    // POLYMORPHISM: unique movement pattern
    @Override
    protected void move() {
        setY(getY() + getSpeed());
        moveTimer++;
        setX(getX() + (int)(Math.sin(moveTimer * 0.05) * 2));
    }

    @Override
    public void render(Graphics g) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();

        // Body
        g.setColor(new Color(180, 50, 220));
        int[] bx = { x + w/2, x, x + 8, x + w - 8, x + w };
        int[] by = { y + h, y + 10, y, y, y + 10 };
        g.fillPolygon(bx, by, 5);

        // Eye
        g.setColor(new Color(255, 50, 50));
        g.fillOval(x + w/2 - 6, y + 8, 12, 12);
        g.setColor(Color.WHITE);
        g.fillOval(x + w/2 - 3, y + 10, 5, 5);

        // Health bar
        drawHealthBar(g, x, y, w);
    }

    private void drawHealthBar(Graphics g, int x, int y, int w) {
        int barW = w;
        int barH = 4;
        int barY = y - 8;
        g.setColor(Color.DARK_GRAY);
        g.fillRect(x, barY, barW, barH);
        int filled = (int)((getHealth() / (float) getMaxHealth()) * barW);
        g.setColor(new Color(0, 220, 80));
        g.fillRect(x, barY, filled, barH);
    }

    @Override
    public void update() {
        super.update();
        shoot();
    }
}
