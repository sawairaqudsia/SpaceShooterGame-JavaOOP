package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

/**
 * INHERITANCE: BossEnemy extends Enemy
 * POLYMORPHISM: Overrides shoot() to fire spread bullets, unique movement
 */
public class BossEnemy extends Enemy {

    private int direction = 1;
    private int phase = 1; // Boss gets faster at low health
    private int shootPattern = 0;

    public BossEnemy(int x, int y, List<Bullet> bulletList) {
        super(x, y, 90, 70, 300, 1, 1000, 50, bulletList);
    }

    @Override
    protected void move() {
        // Move down to position, then sweep left/right
        if (getY() < 80) {
            setY(getY() + 1);
        } else {
            int nx = getX() + direction * (phase == 2 ? 3 : 2);
            if (nx < 0 || nx > 710) direction *= -1;
            setX(getX() + direction * (phase == 2 ? 3 : 2));
        }

        // Enter phase 2 at half health
        if (getHealth() < getMaxHealth() / 2) phase = 2;
    }

    // POLYMORPHISM: Boss fires a 3-bullet spread
    @Override
    public void shoot() {
        int cx = getX() + getWidth() / 2;
        int by = getY() + getHeight();

        bulletList.add(new Bullet(cx - 2, by, 5, 15, false));

        if (shootPattern % 2 == 0) {
            bulletList.add(new Bullet(cx - 22, by - 10, 5, 15, false));
            bulletList.add(new Bullet(cx + 18, by - 10, 5, 15, false));
        }
        shootPattern++;
    }

    @Override
    public void update() {
        super.update();
        shoot();
    }

    @Override
    public void render(Graphics g) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();

        // Body
        Color bodyColor = (phase == 2) ? new Color(200, 30, 30) : new Color(80, 0, 160);
        g.setColor(bodyColor);
        g.fillRoundRect(x, y + 15, w, h - 15, 20, 20);

        // Top dome
        g.setColor(new Color(120, 0, 220));
        g.fillOval(x + 10, y, w - 20, 40);

        // Eyes
        g.setColor(new Color(255, 0, 0));
        g.fillOval(x + 18, y + 20, 16, 16);
        g.fillOval(x + w - 34, y + 20, 16, 16);
        g.setColor(Color.WHITE);
        g.fillOval(x + 22, y + 24, 6, 6);
        g.fillOval(x + w - 30, y + 24, 6, 6);

        // Cannons
        g.setColor(Color.DARK_GRAY);
        g.fillRect(x + 5, y + h - 15, 12, 20);
        g.fillRect(x + w - 17, y + h - 15, 12, 20);
        g.fillRect(x + w/2 - 6, y + h - 10, 12, 18);

        // Health bar (wider for boss)
        int barW = w;
        g.setColor(Color.DARK_GRAY);
        g.fillRect(x, y - 12, barW, 6);
        int filled = (int)((getHealth() / (float) getMaxHealth()) * barW);
        Color hpColor = phase == 2 ? new Color(255, 60, 60) : new Color(60, 200, 255);
        g.setColor(hpColor);
        g.fillRect(x, y - 12, filled, 6);
        g.setColor(Color.WHITE);
        g.drawString("BOSS", x + barW/2 - 14, y - 14);
    }
}
