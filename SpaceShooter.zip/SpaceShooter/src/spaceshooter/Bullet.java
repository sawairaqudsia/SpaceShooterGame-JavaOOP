package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;

/**
 * INHERITANCE: Bullet extends GameObject.
 * Represents projectiles fired by both player and enemies.
 */
public class Bullet extends GameObject {

    // ENCAPSULATION
    private int speed;
    private int damage;
    private Color color;
    private boolean fromPlayer;

    public Bullet(int x, int y, int speed, int damage, boolean fromPlayer) {
        super(x, y, 5, 15);
        this.speed = speed;
        this.damage = damage;
        this.fromPlayer = fromPlayer;
        this.color = fromPlayer ? new Color(0, 255, 200) : new Color(255, 80, 80);
    }

    @Override
    public void update() {
        // Player bullets go up, enemy bullets go down
        if (fromPlayer) {
            setY(getY() - speed);
        } else {
            setY(getY() + speed);
        }

        // Deactivate if out of screen bounds
        if (getY() < -20 || getY() > 700) {
            setActive(false);
        }
    }

    @Override
    public void render(Graphics g) {
        if (!isActive()) return;

        // Glow effect: draw larger translucent background
        g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 80));
        g.fillOval(getX() - 3, getY() - 3, getWidth() + 6, getHeight() + 6);

        // Core bullet
        g.setColor(color);
        g.fillRoundRect(getX(), getY(), getWidth(), getHeight(), 5, 5);

        // Bright center
        g.setColor(Color.WHITE);
        g.fillRoundRect(getX() + 1, getY() + 2, 3, 6, 2, 2);
    }

    // Getters (ENCAPSULATION)
    public int getDamage() { return damage; }
    public boolean isFromPlayer() { return fromPlayer; }
}
