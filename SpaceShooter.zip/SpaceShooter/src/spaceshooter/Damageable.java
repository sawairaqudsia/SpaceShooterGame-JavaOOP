package spaceshooter;

/**
 * INTERFACE: Defines the contract for anything that can take damage.
 */
public interface Damageable {
    void takeDamage(int amount);
    int getHealth();
    boolean isDead();
}
