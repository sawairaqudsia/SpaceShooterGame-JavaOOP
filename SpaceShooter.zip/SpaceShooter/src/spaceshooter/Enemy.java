package spaceshooter;

import java.awt.Graphics;
import java.util.List;

/**
 * ABSTRACTION: Abstract Enemy class — common enemy behavior.
 * INHERITANCE: Extends GameObject.
 * INTERFACES: Implements Shootable and Damageable.
 * Subclasses will OVERRIDE render() and shoot() differently = POLYMORPHISM.
 */
public abstract class Enemy extends GameObject implements Shootable, Damageable {

    // ENCAPSULATION
    private int health;
    private int maxHealth;
    private int speed;
    private int scoreValue;
    private int fireCooldown;
    private int fireRate;
    protected List<Bullet> bulletList;

    public Enemy(int x, int y, int width, int height,
                 int health, int speed, int scoreValue, int fireRate,
                 List<Bullet> bulletList) {
        super(x, y, width, height);
        this.health = health;
        this.maxHealth = health;
        this.speed = speed;
        this.scoreValue = scoreValue;
        this.fireCooldown = 0;
        this.fireRate = fireRate;
        this.bulletList = bulletList;
    }

    @Override
    public void update() {
        move();
        if (fireCooldown > 0) fireCooldown--;
        if (getY() > 700) setActive(false);
    }

    // ABSTRACTION: subclasses define movement pattern
    protected abstract void move();

    // Base shoot — subclasses can override (POLYMORPHISM)
    @Override
    public void shoot() {
        if (fireCooldown <= 0) {
            int bx = getX() + getWidth() / 2 - 2;
            int by = getY() + getHeight();
            bulletList.add(new Bullet(bx, by, 5, 10, false));
            fireCooldown = fireRate;
        }
    }

    @Override
    public int getFireRate() { return fireRate; }

    @Override
    public void takeDamage(int amount) {
        health -= amount;
        if (health <= 0) {
            health = 0;
            setActive(false);
        }
    }

    @Override
    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }

    @Override
    public boolean isDead() { return health <= 0; }

    public int getScoreValue() { return scoreValue; }
    protected int getSpeed() { return speed; }
    protected void setSpeed(int speed) { this.speed = speed; }
    protected void resetFireCooldown() { fireCooldown = fireRate; }
}
