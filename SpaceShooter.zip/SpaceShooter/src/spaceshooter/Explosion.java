package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;

/**
 * INHERITANCE: Explosion extends GameObject
 * Visual explosion effect shown when enemies/player are destroyed
 */
public class Explosion extends GameObject {

    private int frame;
    private int maxFrames;
    private Color color;

    public Explosion(int x, int y, int size, Color color) {
        super(x - size/2, y - size/2, size, size);
        this.frame = 0;
        this.maxFrames = 30;
        this.color = color;
    }

    @Override
    public void update() {
        frame++;
        if (frame >= maxFrames) setActive(false);
    }

    @Override
    public void render(Graphics g) {
        if (!isActive()) return;

        float progress = (float) frame / maxFrames;
        int alpha = (int)(255 * (1 - progress));
        int size = (int)(getWidth() * progress * 2);
        int x = getX() - size/4;
        int y = getY() - size/4;

        // Outer ring
        g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(alpha, 255)));
        g.fillOval(x, y, size, size);

        // Inner bright flash
        int innerSize = size / 2;
        g.setColor(new Color(255, 255, 200, Math.min(alpha * 2, 255)));
        g.fillOval(x + innerSize/2, y + innerSize/2, innerSize, innerSize);
    }
}
