package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

/**
 * INHERITANCE: FastEnemy extends Enemy
 * POLYMORPHISM: Different speed and movement pattern from BasicEnemy
 */
public class FastEnemy extends Enemy {

    private int direction = 1;
    private int bounceTimer = 0;

    public FastEnemy(int x, int y, List<Bullet> bulletList) {
        super(x, y, 34, 30, 20, 4, 150, 60, bulletList);
    }

    @Override
    protected void move() {
        setY(getY() + getSpeed());
        bounceTimer++;
        if (bounceTimer > 40) {
            direction *= -1;
            bounceTimer = 0;
        }
        int nx = getX() + direction * 3;
        if (nx > 0 && nx < 766) setX(nx);
    }

    @Override
    public void render(Graphics g) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();

        // Sleek triangular body
        g.setColor(new Color(255, 120, 0));
        int[] bx = { x + w/2, x, x + w };
        int[] by = { y, y + h, y + h };
        g.fillPolygon(bx, by, 3);

        // Core glow
        g.setColor(new Color(255, 220, 100, 180));
        g.fillOval(x + w/2 - 5, y + h/2 - 5, 10, 10);

        // Health bar
        g.setColor(Color.DARK_GRAY);
        g.fillRect(x, y - 8, w, 4);
        int filled = (int)((getHealth() / (float) getMaxHealth()) * w);
        g.setColor(new Color(255, 180, 0));
        g.fillRect(x, y - 8, filled, 4);
    }

    @Override
    public void update() {
        super.update();
        shoot();
    }
}
