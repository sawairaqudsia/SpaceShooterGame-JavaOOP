package spaceshooter;

import java.awt.Graphics;

/**
 * ABSTRACTION: Abstract base class for all game objects.
 * Defines common properties and forces subclasses to implement render/update.
 */
public abstract class GameObject {

    // ENCAPSULATION: private fields with getters/setters
    private int x, y;
    private int width, height;
    private boolean active;

    public GameObject(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.active = true;
    }

    // ABSTRACTION: abstract methods that every subclass must implement
    public abstract void update();
    public abstract void render(Graphics g);

    // Getters and Setters (ENCAPSULATION)
    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public boolean isActive() { return active; }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setWidth(int width) { this.width = width; }
    public void setHeight(int height) { this.height = height; }
    public void setActive(boolean active) { this.active = active; }

    /**
     * Simple AABB collision detection
     */
    public boolean collidesWith(GameObject other) {
        return this.x < other.x + other.width &&
               this.x + this.width > other.x &&
               this.y < other.y + other.height &&
               this.y + this.height > other.y;
    }
}
