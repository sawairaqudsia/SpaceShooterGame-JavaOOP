package spaceshooter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * GameOverPanel: Shown when the player loses all lives.
 * Features final score display and Play Again / Menu buttons.
 */
public class GameOverPanel extends JPanel {

    private SpaceShooterGame mainFrame;
    private int finalScore;
    private StarBackground stars;
    private Timer animTimer;
    private int alpha = 0;

    public GameOverPanel(SpaceShooterGame mainFrame, int score) {
        this.mainFrame  = mainFrame;
        this.finalScore = score;
        setPreferredSize(new Dimension(GamePanel.WIDTH, GamePanel.HEIGHT));
        setBackground(new Color(5, 0, 20));
        setLayout(null);
        stars = new StarBackground(100, GamePanel.WIDTH, GamePanel.HEIGHT);
        buildUI();
        startAnim();
    }

    private void buildUI() {
        // Play Again
        JButton playAgainBtn = createBtn("↺  PLAY AGAIN", 250, 420, 140, 48);
        playAgainBtn.addActionListener(e -> mainFrame.startGame());
        add(playAgainBtn);

        // Main Menu
        JButton menuBtn = createBtn("⌂  MAIN MENU", 410, 420, 140, 48);
        menuBtn.addActionListener(e -> mainFrame.showMenu());
        add(menuBtn);
    }

    private JButton createBtn(String text, int x, int y, int w, int h) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()
                        ? new Color(200, 40, 40)
                        : new Color(120, 20, 20));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.setColor(new Color(255, 100, 100));
                g2.setStroke(new BasicStroke(2));
                g2.drawRoundRect(1, 1, getWidth()-2, getHeight()-2, 14, 14);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 15));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(),
                        (getWidth() - fm.stringWidth(getText())) / 2,
                        (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        btn.setBounds(x, y, w, h);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void startAnim() {
        animTimer = new Timer(16, e -> {
            if (alpha < 255) alpha = Math.min(255, alpha + 5);
            stars.update();
            repaint();
        });
        animTimer.start();
    }

    public void stopAnimations() {
        if (animTimer != null) animTimer.stop();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(new Color(5, 0, 20));
        g2.fillRect(0, 0, getWidth(), getHeight());
        stars.render(g2);

        // Red glow
        g2.setColor(new Color(180, 0, 0, 40));
        g2.fillOval(100, 100, 600, 300);

        // GAME OVER text
        g2.setFont(new Font("Arial", Font.BOLD, 72));
        String go = "GAME OVER";
        FontMetrics fm = g2.getFontMetrics();
        int tx = (getWidth() - fm.stringWidth(go)) / 2;
        g2.setColor(new Color(0, 0, 0, alpha / 2));
        g2.drawString(go, tx + 4, 244);
        g2.setColor(new Color(255, 60, 60, alpha));
        g2.drawString(go, tx, 240);

        // Score
        g2.setFont(new Font("Arial", Font.BOLD, 32));
        String sc = "FINAL SCORE:  " + finalScore;
        g2.setColor(new Color(255, 220, 100, alpha));
        fm = g2.getFontMetrics();
        g2.drawString(sc, (getWidth() - fm.stringWidth(sc)) / 2, 320);

        // Rating
        g2.setFont(new Font("Arial", Font.ITALIC, 20));
        String rating = getRating(finalScore);
        g2.setColor(new Color(200, 200, 255, alpha));
        fm = g2.getFontMetrics();
        g2.drawString(rating, (getWidth() - fm.stringWidth(rating)) / 2, 370);
    }

    private String getRating(int score) {
        if (score >= 5000) return "★★★  ACE COMMANDER  ★★★";
        if (score >= 2000) return "★★☆  VETERAN PILOT  ★★☆";
        if (score >= 800)  return "★☆☆  ROOKIE PILOT  ★☆☆";
        return "☆☆☆  KEEP TRAINING  ☆☆☆";
    }
}
