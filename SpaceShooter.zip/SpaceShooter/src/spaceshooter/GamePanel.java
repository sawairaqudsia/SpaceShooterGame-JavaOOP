package spaceshooter;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.swing.*;

/**
 * GamePanel: Core game loop using Runnable + Thread.
 * Handles input, updating all objects, collision detection, and rendering.
 * ENCAPSULATION: All game state is private.
 */
public class GamePanel extends JPanel implements Runnable, KeyListener {

    // Screen constants
    public static final int WIDTH  = 800;
    public static final int HEIGHT = 700;
    private static final int FPS   = 60;

    // Game objects
    private Player player;
    private List<Bullet>    bullets;
    private List<Enemy>     enemies;
    private List<Explosion> explosions;
    private StarBackground  stars;

    // Game state
    private boolean running;
    private boolean paused;
    private Thread  gameThread;

    private int wave;
    private int enemySpawnTimer;
    private int waveEnemiesLeft;
    private boolean bossSpawned;
    private boolean waveCleared;
    private int waveClearTimer;

    // Input flags
    private boolean leftPressed, rightPressed, upPressed, downPressed, spacePressed;

    // Callback to switch screens
    private SpaceShooterGame mainFrame;

    // Random
    private Random rand = new Random();

    public GamePanel(SpaceShooterGame mainFrame) {
        this.mainFrame = mainFrame;
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        initGame();
    }

    private void initGame() {
        bullets    = new ArrayList<>();
        enemies    = new ArrayList<>();
        explosions = new ArrayList<>();
        stars      = new StarBackground(120, WIDTH, HEIGHT);
        player     = new Player(WIDTH / 2 - 24, HEIGHT - 100, bullets);

        wave             = 1;
        enemySpawnTimer  = 0;
        waveEnemiesLeft  = getEnemiesForWave(wave);
        bossSpawned      = false;
        waveCleared      = false;
        waveClearTimer   = 0;
        paused           = false;
    }

    private int getEnemiesForWave(int w) {
        return 5 + (w - 1) * 3;
    }

    // ─── Game Loop ────────────────────────────────────────────────────────────

    public void startGame() {
        running    = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void stopGame() {
        running = false;
    }

    @Override
    public void run() {
        long targetTime = 1000 / FPS;
        while (running) {
            long start = System.currentTimeMillis();
            if (!paused) {
                update();
            }
            repaint();
            long elapsed = System.currentTimeMillis() - start;
            long sleep   = targetTime - elapsed;
            if (sleep > 0) {
                try { Thread.sleep(sleep); } catch (InterruptedException ignored) {}
            }
        }
    }

    // ─── Update ───────────────────────────────────────────────────────────────

    private void update() {
        stars.update();

        // Player input
        if (leftPressed)  player.moveLeft();
        if (rightPressed) player.moveRight();
        if (upPressed)    player.moveUp();
        if (downPressed)  player.moveDown();
        if (spacePressed) player.shoot();

        player.update();

        // Check player death
        if (player.isDead()) {
            running = false;
            SwingUtilities.invokeLater(() -> mainFrame.showGameOver(player.getScore()));
            return;
        }

        // Spawn enemies
        spawnEnemies();

        // Update bullets
        Iterator<Bullet> bi = bullets.iterator();
        while (bi.hasNext()) {
            Bullet b = bi.next();
            b.update();
            if (!b.isActive()) { bi.remove(); continue; }

            // Player bullet hits enemy
            if (b.isFromPlayer()) {
                Iterator<Enemy> ei = enemies.iterator();
                while (ei.hasNext()) {
                    Enemy e = ei.next();
                    if (e.isActive() && b.collidesWith(e)) {
                        e.takeDamage(b.getDamage());
                        b.setActive(false);
                        if (e.isDead()) {
                            player.addScore(e.getScoreValue());
                            explosions.add(new Explosion(
                                e.getX() + e.getWidth()/2,
                                e.getY() + e.getHeight()/2,
                                e.getWidth(), new Color(255, 120, 0)));
                        }
                        break;
                    }
                }
            } else {
                // Enemy bullet hits player
                if (b.isActive() && b.collidesWith(player)) {
                    player.takeDamage(b.getDamage());
                    b.setActive(false);
                    explosions.add(new Explosion(
                        player.getX() + player.getWidth()/2,
                        player.getY() + player.getHeight()/2,
                        20, new Color(0, 150, 255)));
                }
            }
        }

        // Update enemies
        Iterator<Enemy> ei = enemies.iterator();
        while (ei.hasNext()) {
            Enemy e = ei.next();
            e.update();

            // Enemy collides directly with player
            if (e.isActive() && e.collidesWith(player)) {
                player.takeDamage(30);
                e.setActive(false);
                explosions.add(new Explosion(
                    e.getX() + e.getWidth()/2,
                    e.getY() + e.getHeight()/2,
                    e.getWidth(), new Color(255, 60, 0)));
            }

            if (!e.isActive()) ei.remove();
        }

        // Update explosions
        Iterator<Explosion> xi = explosions.iterator();
        while (xi.hasNext()) {
            Explosion x = xi.next();
            x.update();
            if (!x.isActive()) xi.remove();
        }

        // Wave cleared?
        if (enemies.isEmpty() && waveEnemiesLeft <= 0 && !waveCleared) {
            waveCleared    = true;
            waveClearTimer = 180; // 3 seconds
        }
        if (waveCleared) {
            waveClearTimer--;
            if (waveClearTimer <= 0) {
                wave++;
                waveEnemiesLeft = getEnemiesForWave(wave);
                bossSpawned     = false;
                waveCleared     = false;
            }
        }
    }

    private void spawnEnemies() {
        if (waveEnemiesLeft <= 0) return;

        enemySpawnTimer++;
        int interval = Math.max(40, 80 - wave * 5);

        if (enemySpawnTimer >= interval) {
            enemySpawnTimer = 0;

            // Spawn boss every 3 waves
            if (wave % 3 == 0 && !bossSpawned && waveEnemiesLeft == 1) {
                enemies.add(new BossEnemy(WIDTH/2 - 45, -80, bullets));
                bossSpawned = true;
                waveEnemiesLeft--;
                return;
            }

            int x = rand.nextInt(WIDTH - 60) + 10;
            if (wave >= 2 && rand.nextBoolean()) {
                enemies.add(new FastEnemy(x, -40, bullets));
            } else {
                enemies.add(new BasicEnemy(x, -50, bullets));
            }
            waveEnemiesLeft--;
        }
    }

    // ─── Render ───────────────────────────────────────────────────────────────

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Background
        g.setColor(new Color(5, 0, 20));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        stars.render(g);

        // Game objects
        for (Explosion ex : explosions) ex.render(g);
        for (Bullet b : bullets)       b.render(g);
        for (Enemy e : enemies)        e.render(g);
        player.render(g);

        // HUD
        drawHUD(g);

        // Wave cleared message
        if (waveCleared) {
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.setColor(new Color(0, 255, 180));
            String msg = "WAVE " + wave + " CLEARED!";
            int sw = g.getFontMetrics().stringWidth(msg);
            g.drawString(msg, WIDTH/2 - sw/2, HEIGHT/2);
        }

        if (paused) drawPauseOverlay(g);
    }

    private void drawHUD(Graphics g) {
        // Score
        g.setFont(new Font("Arial", Font.BOLD, 18));
        g.setColor(Color.WHITE);
        g.drawString("SCORE: " + player.getScore(), 10, 28);

        // Wave
        g.drawString("WAVE: " + wave, WIDTH/2 - 40, 28);

        // Lives
        g.drawString("LIVES: " + player.getLives(), WIDTH - 110, 28);

        // Health bar
        int barW = 160, barH = 14;
        int barX = 10, barY = 38;
        g.setColor(Color.DARK_GRAY);
        g.fillRect(barX, barY, barW, barH);
        int hpW = (int)((player.getHealth() / (float) player.getMaxHealth()) * barW);
        g.setColor(new Color(0, 220, 80));
        g.fillRect(barX, barY, hpW, barH);
        g.setColor(Color.WHITE);
        g.drawRect(barX, barY, barW, barH);
        g.setFont(new Font("Arial", Font.PLAIN, 11));
        g.drawString("HP: " + player.getHealth() + "/" + player.getMaxHealth(), barX + 4, barY + 11);

        // Pause hint
        g.setFont(new Font("Arial", Font.PLAIN, 12));
        g.setColor(new Color(150, 150, 150));
        g.drawString("P = Pause   ESC = Menu", WIDTH - 180, HEIGHT - 10);
    }

    private void drawPauseOverlay(Graphics g) {
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        g.setColor(Color.CYAN);
        String p = "PAUSED";
        g.drawString(p, WIDTH/2 - g.getFontMetrics().stringWidth(p)/2, HEIGHT/2 - 20);
        g.setFont(new Font("Arial", Font.PLAIN, 20));
        g.setColor(Color.WHITE);
        String hint = "Press P to Resume";
        g.drawString(hint, WIDTH/2 - g.getFontMetrics().stringWidth(hint)/2, HEIGHT/2 + 30);
    }

    // ─── Key Input ────────────────────────────────────────────────────────────

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:  case KeyEvent.VK_A: leftPressed  = true; break;
            case KeyEvent.VK_RIGHT: case KeyEvent.VK_D: rightPressed = true; break;
            case KeyEvent.VK_UP:    case KeyEvent.VK_W: upPressed    = true; break;
            case KeyEvent.VK_DOWN:  case KeyEvent.VK_S: downPressed  = true; break;
            case KeyEvent.VK_SPACE: spacePressed = true; break;
            case KeyEvent.VK_P:     paused = !paused;   break;
            case KeyEvent.VK_ESCAPE:
                stopGame();
                SwingUtilities.invokeLater(() -> mainFrame.showMenu());
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:  case KeyEvent.VK_A: leftPressed  = false; break;
            case KeyEvent.VK_RIGHT: case KeyEvent.VK_D: rightPressed = false; break;
            case KeyEvent.VK_UP:    case KeyEvent.VK_W: upPressed    = false; break;
            case KeyEvent.VK_DOWN:  case KeyEvent.VK_S: downPressed  = false; break;
            case KeyEvent.VK_SPACE: spacePressed = false; break;
        }
    }

    @Override public void keyTyped(KeyEvent e) {}

    public void resetGame() {
        bullets.clear();
        enemies.clear();
        explosions.clear();
        initGame();
    }
}
