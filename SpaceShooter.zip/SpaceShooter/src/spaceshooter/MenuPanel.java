package spaceshooter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * MenuPanel: The main menu screen.
 * ENCAPSULATION: private components and state.
 * Demonstrates use of JButton with custom styling.
 */
public class MenuPanel extends JPanel {

    private SpaceShooterGame mainFrame;
    private int titleAlpha = 0;
    private Timer animTimer;
    private StarBackground stars;

    // Custom styled button colors
    private static final Color BTN_BG     = new Color(20, 60, 140);
    private static final Color BTN_HOVER  = new Color(0, 140, 255);
    private static final Color BTN_TEXT   = Color.WHITE;
    private static final Color BTN_BORDER = new Color(0, 200, 255);

    public MenuPanel(SpaceShooterGame mainFrame) {
        this.mainFrame = mainFrame;
        setPreferredSize(new Dimension(GamePanel.WIDTH, GamePanel.HEIGHT));
        setBackground(new Color(5, 0, 20));
        setLayout(null); // absolute positioning

        stars = new StarBackground(100, GamePanel.WIDTH, GamePanel.HEIGHT);

        buildUI();
        startAnimations();
    }

    private void buildUI() {
        // ── Play Button ─────────────────────────────────────────
        JButton playBtn = createStyledButton("▶  PLAY GAME", 300, 320, 200, 50);
        playBtn.addActionListener(e -> mainFrame.startGame());
        add(playBtn);

        // ── How To Play Button ───────────────────────────────────
        JButton howBtn = createStyledButton("?  HOW TO PLAY", 300, 390, 200, 50);
        howBtn.addActionListener(e -> showInstructions());
        add(howBtn);

        // ── Exit Button ──────────────────────────────────────────
        JButton exitBtn = createStyledButton("✕  EXIT", 300, 460, 200, 50);
        exitBtn.addActionListener(e -> System.exit(0));
        add(exitBtn);
    }

    /**
     * Factory method for creating consistently styled buttons.
     * ENCAPSULATION: button styling logic in one place.
     */
    private JButton createStyledButton(String text, int x, int y, int w, int h) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Background
                if (getModel().isRollover()) {
                    g2.setColor(BTN_HOVER);
                } else {
                    g2.setColor(BTN_BG);
                }
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);

                // Border
                g2.setColor(BTN_BORDER);
                g2.setStroke(new BasicStroke(2));
                g2.drawRoundRect(1, 1, getWidth()-2, getHeight()-2, 16, 16);

                // Text
                g2.setColor(BTN_TEXT);
                g2.setFont(new Font("Arial", Font.BOLD, 18));
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(getText())) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(getText(), tx, ty);
                g2.dispose();
            }
        };

        btn.setBounds(x, y, w, h);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void showInstructions() {
        String msg =
            "🚀  HOW TO PLAY  🚀\n\n" +
            "MOVE:   Arrow Keys or W A S D\n" +
            "SHOOT:  SPACE (hold for rapid fire)\n" +
            "PAUSE:  P\n" +
            "MENU:   ESC\n\n" +
            "Destroy enemies to earn points.\n" +
            "A BOSS appears every 3 waves!\n" +
            "You have 3 lives — don't lose them all!\n\n" +
            "Good luck, Commander!";
        JOptionPane.showMessageDialog(this, msg, "How To Play",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void startAnimations() {
        // Fade-in title + scroll stars
        animTimer = new Timer(16, e -> {
            if (titleAlpha < 255) titleAlpha = Math.min(255, titleAlpha + 4);
            stars.update();
            repaint();
        });
        animTimer.start();
    }

    public void stopAnimations() {
        if (animTimer != null) animTimer.stop();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Deep space background
        g2.setColor(new Color(5, 0, 20));
        g2.fillRect(0, 0, getWidth(), getHeight());

        stars.render(g2);

        // Title glow backdrop
        g2.setColor(new Color(0, 100, 255, 40));
        g2.fillOval(150, 80, 500, 180);

        // Title text with fade-in
        g2.setFont(new Font("Arial", Font.BOLD, 56));
        String title = "SPACE SHOOTER";
        FontMetrics fm = g2.getFontMetrics();
        int tx = (getWidth() - fm.stringWidth(title)) / 2;

        // Shadow
        g2.setColor(new Color(0, 0, 0, titleAlpha / 2));
        g2.drawString(title, tx + 3, 183);

        // Main title
        g2.setColor(new Color(0, 200, 255, titleAlpha));
        g2.drawString(title, tx, 180);

        // Subtitle
        g2.setFont(new Font("Arial", Font.ITALIC, 18));
        g2.setColor(new Color(180, 180, 255, titleAlpha));
        String sub = "Java OOP Semester Project";
        g2.drawString(sub, (getWidth() - g2.getFontMetrics().stringWidth(sub)) / 2, 220);

        // Decorative line
        g2.setColor(new Color(0, 200, 255, 120));
        g2.setStroke(new BasicStroke(2));
        g2.drawLine(200, 265, 600, 265);

        // Small ship icon
        drawShipIcon(g2, getWidth() / 2, 292);

        // Footer
        g2.setFont(new Font("Arial", Font.PLAIN, 13));
        g2.setColor(new Color(100, 100, 150));
        String footer = "OOP Concepts: Inheritance · Polymorphism · Encapsulation · Abstraction · Interfaces";
        g2.drawString(footer, (getWidth() - g2.getFontMetrics().stringWidth(footer)) / 2,
                getHeight() - 15);
    }

    private void drawShipIcon(Graphics2D g2, int cx, int cy) {
        g2.setColor(new Color(30, 120, 255, titleAlpha));
        int[] bx = { cx, cx - 14, cx - 10, cx + 10, cx + 14 };
        int[] by = { cy - 16, cy + 6, cy + 14, cy + 14, cy + 6 };
        g2.fillPolygon(bx, by, 5);
        g2.setColor(new Color(150, 220, 255, titleAlpha));
        int[] cx2 = { cx, cx - 5, cx + 5 };
        int[] cy2 = { cy - 10, cy + 2, cy + 2 };
        g2.fillPolygon(cx2, cy2, 3);
    }
}
