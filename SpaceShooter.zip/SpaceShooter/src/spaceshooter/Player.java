package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

/**
 * INHERITANCE: Player extends GameObject.
 * INTERFACES: Implements both Shootable and Damageable.
 * ENCAPSULATION: All fields are private with controlled access.
 */
public class Player extends GameObject implements Shootable, Damageable {

    // ENCAPSULATION: private fields
    private int health;
    private int maxHealth;
    private int speed;
    private int fireRate;       // frames between shots
    private int fireCooldown;
    private int score;
    private int lives;
    private boolean invincible; // brief invincibility after hit
    private int invincibleTimer;
    private List<Bullet> bulletList;

    public Player(int x, int y, List<Bullet> bulletList) {
        super(x, y, 48, 48);
        this.health = 100;
        this.maxHealth = 100;
        this.speed = 5;
        this.fireRate = 12;
        this.fireCooldown = 0;
        this.score = 0;
        this.lives = 3;
        this.invincible = false;
        this.invincibleTimer = 0;
        this.bulletList = bulletList;
    }

    @Override
    public void update() {
        if (fireCooldown > 0) fireCooldown--;

        if (invincible) {
            invincibleTimer--;
            if (invincibleTimer <= 0) invincible = false;
        }
    }

    // POLYMORPHISM: implements Shootable interface
    @Override
    public void shoot() {
        if (fireCooldown <= 0) {
            int bx = getX() + getWidth() / 2 - 2;
            int by = getY() - 10;
            bulletList.add(new Bullet(bx, by, 10, 20, true));
            fireCooldown = fireRate;
        }
    }

    @Override
    public int getFireRate() { return fireRate; }

    // POLYMORPHISM: implements Damageable interface
    @Override
    public void takeDamage(int amount) {
        if (!invincible) {
            health -= amount;
            invincible = true;
            invincibleTimer = 90; // 1.5 seconds at 60fps
            if (health <= 0) {
                health = 0;
                lives--;
                if (lives > 0) {
                    health = maxHealth;
                }
            }
        }
    }

    @Override
    public int getHealth() { return health; }

    @Override
    public boolean isDead() { return lives <= 0 && health <= 0; }

    @Override
    public void render(Graphics g) {
        // Flicker when invincible
        if (invincible && (invincibleTimer / 5) % 2 == 0) return;

        int x = getX(), y = getY(), w = getWidth(), h = getHeight();

        // Engine glow
        g.setColor(new Color(0, 180, 255, 120));
        g.fillOval(x + w / 2 - 10, y + h - 5, 20, 18);

        // Main body
        int[] bodyX = { x + w / 2, x + 5, x + 10, x + w - 10, x + w - 5 };
        int[] bodyY = { y, y + h - 10, y + h, y + h, y + h - 10 };
        g.setColor(new Color(30, 120, 255));
        g.fillPolygon(bodyX, bodyY, 5);

        // Cockpit
        g.setColor(new Color(150, 220, 255));
        int[] cockpitX = { x + w / 2, x + w / 2 - 8, x + w / 2 + 8 };
        int[] cockpitY = { y + 5, y + 22, y + 22 };
        g.fillPolygon(cockpitX, cockpitY, 3);

        // Wings
        g.setColor(new Color(20, 80, 200));
        int[] lwX = { x + 5, x, x + 15 };
        int[] lwY = { y + h - 10, y + h + 10, y + h - 5 };
        g.fillPolygon(lwX, lwY, 3);

        int[] rwX = { x + w - 5, x + w, x + w - 15 };
        int[] rwY = { y + h - 10, y + h + 10, y + h - 5 };
        g.fillPolygon(rwX, rwY, 3);

        // Engine flames
        g.setColor(new Color(255, 140, 0));
        g.fillOval(x + w / 2 - 7, y + h - 2, 14, 12);
        g.setColor(new Color(255, 220, 0));
        g.fillOval(x + w / 2 - 4, y + h, 8, 8);
    }

    // Movement methods
    public void moveLeft()  { if (getX() > 0) setX(getX() - speed); }
    public void moveRight() { if (getX() < 752) setX(getX() + speed); }
    public void moveUp()    { if (getY() > 0) setY(getY() - speed); }
    public void moveDown()  { if (getY() < 600) setY(getY() + speed); }

    // Getters (ENCAPSULATION)
    public int getScore()    { return score; }
    public int getLives()    { return lives; }
    public int getMaxHealth(){ return maxHealth; }

    public void addScore(int points) { this.score += points; }
    public void setHealth(int health){ this.health = health; }
}
