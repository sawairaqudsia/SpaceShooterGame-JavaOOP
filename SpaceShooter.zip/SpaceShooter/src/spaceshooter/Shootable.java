package spaceshooter;

/**
 * INTERFACE: Defines the contract for anything that can shoot.
 * Demonstrates Interface usage in OOP.
 */
public interface Shootable {
    void shoot();
    int getFireRate(); // bullets per second
}
