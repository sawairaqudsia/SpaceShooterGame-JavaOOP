package spaceshooter;

import javax.swing.*;

/**
 * SpaceShooterGame: Main JFrame that manages screen switching.
 * Entry point of the application — contains the main() method.
 *
 * OOP Concepts Demonstrated:
 *  - INHERITANCE      : Player, BasicEnemy, FastEnemy, BossEnemy, Bullet, Explosion extend GameObject
 *  - POLYMORPHISM     : update()/render()/shoot()/takeDamage() behave differently per subclass
 *  - ENCAPSULATION    : All fields are private; accessed via getters/setters
 *  - ABSTRACTION      : GameObject and Enemy are abstract classes; Shootable/Damageable are interfaces
 *  - INTERFACES       : Shootable, Damageable implemented by Player and Enemy subclasses
 *  - BUTTONS          : JButton components in MenuPanel and GameOverPanel with custom rendering
 */
public class SpaceShooterGame extends JFrame {

    private GamePanel    gamePanel;
    private MenuPanel    menuPanel;
    private GameOverPanel gameOverPanel;

    public SpaceShooterGame() {
        setTitle("Space Shooter — Java OOP Project");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        showMenu(); // start at main menu
        pack();
        setLocationRelativeTo(null); // center on screen
        setVisible(true);
    }

    /** Show the main menu. */
    public void showMenu() {
        if (gamePanel != null)     gamePanel.stopGame();
        if (gameOverPanel != null) gameOverPanel.stopAnimations();

        menuPanel = new MenuPanel(this);
        setContentPane(menuPanel);
        revalidate();
        repaint();
    }

    /** Start / restart the game. */
    public void startGame() {
        if (menuPanel    != null) menuPanel.stopAnimations();
        if (gameOverPanel != null) gameOverPanel.stopAnimations();

        if (gamePanel == null) {
            gamePanel = new GamePanel(this);
        } else {
            gamePanel.resetGame();
        }

        setContentPane(gamePanel);
        revalidate();
        repaint();
        pack();

        // Request focus so KeyListener works
        gamePanel.requestFocusInWindow();
        gamePanel.startGame();
    }

    /** Show game-over screen with final score. */
    public void showGameOver(int score) {
        if (gamePanel != null) gamePanel.stopGame();
        gameOverPanel = new GameOverPanel(this, score);
        setContentPane(gameOverPanel);
        revalidate();
        repaint();
    }

    // ─── Main Method ─────────────────────────────────────────────────────────

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SpaceShooterGame());
    }
}
