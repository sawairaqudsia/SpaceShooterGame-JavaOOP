package spaceshooter;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

/**
 * StarBackground: Scrolling parallax star field for the game background.
 */
public class StarBackground {

    private int[] starX, starY, starSize, starSpeed;
    private int[] starAlpha;
    private int count;
    private Random rand;

    public StarBackground(int count, int screenWidth, int screenHeight) {
        this.count = count;
        rand = new Random();
        starX     = new int[count];
        starY     = new int[count];
        starSize  = new int[count];
        starSpeed = new int[count];
        starAlpha = new int[count];

        for (int i = 0; i < count; i++) {
            starX[i]     = rand.nextInt(screenWidth);
            starY[i]     = rand.nextInt(screenHeight);
            starSize[i]  = rand.nextInt(3) + 1;
            starSpeed[i] = starSize[i];          // bigger stars scroll faster (parallax)
            starAlpha[i] = rand.nextInt(155) + 100;
        }
    }

    public void update() {
        for (int i = 0; i < count; i++) {
            starY[i] += starSpeed[i];
            if (starY[i] > 700) {
                starY[i] = 0;
                starX[i] = rand.nextInt(800);
            }
        }
    }

    public void render(Graphics g) {
        for (int i = 0; i < count; i++) {
            g.setColor(new Color(255, 255, 255, starAlpha[i]));
            g.fillOval(starX[i], starY[i], starSize[i], starSize[i]);
        }
    }
}
